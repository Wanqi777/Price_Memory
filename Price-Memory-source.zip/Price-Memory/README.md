# Price Memory — The 11.11 Study

An interactive computational-thinking project about how a sale's reference price shapes the discount a shopper sees.

## Open the prototype

Open `dist/index.html` in a modern browser. The prototype uses local assets and vanilla HTML, CSS, and JavaScript. No build step, external library, checkout, or tracking is required.

## Explore

- Switch between the shopper storefront and merchant studio.
- In the shopper view, reveal how the advertised discount compares with the usual-price saving.
- In the merchant studio, adjust the pre-event reference price and compare a raise-first promotion with a coupon strategy.
- Review the reflection and design evolution in `docs/` and `screenshots/`.

## Model boundary

The product and prices are fictional. The seller model starts with 100 hypothetical orders and uses an adjustable assumed relationship between advertised discount and modeled orders. It estimates gross sales, not profit, and does not claim that every merchant uses this tactic.
