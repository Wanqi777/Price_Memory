import AppKit
import Foundation

let output = "/Users/wuwanqi/Documents/ChatGPT/5013/Labs/discount-illusion/screenshots/comparison-v2-v5.png"
let versions: [(Int, String)] = [
    (2, "Early refinement"),
    (3, "Guided shopper journey"),
    (4, "Shopper + merchant views"),
    (5, "Photo-led narrative")
]
let canvas = NSSize(width: 1260, height: 930)
let bitmap = NSBitmapImageRep(
    bitmapDataPlanes: nil,
    pixelsWide: Int(canvas.width),
    pixelsHigh: Int(canvas.height),
    bitsPerSample: 8,
    samplesPerPixel: 4,
    hasAlpha: true,
    isPlanar: false,
    colorSpaceName: .deviceRGB,
    bytesPerRow: 0,
    bitsPerPixel: 0
)!
let context = NSGraphicsContext(bitmapImageRep: bitmap)!
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = context
context.imageInterpolation = .high

NSColor(calibratedRed: 0.965, green: 0.957, blue: 0.937, alpha: 1).setFill()
NSBezierPath(rect: NSRect(origin: .zero, size: canvas)).fill()
("PRICE MEMORY  /  DESIGN ARCHIVE" as NSString).draw(
    at: NSPoint(x: 30, y: 895),
    withAttributes: [.font: NSFont.systemFont(ofSize: 14, weight: .bold), .foregroundColor: NSColor(calibratedRed: 0.81, green: 0.37, blue: 0.27, alpha: 1)]
)
("Four saved interfaces · Versions 2–5" as NSString).draw(
    at: NSPoint(x: 30, y: 871),
    withAttributes: [.font: NSFont.systemFont(ofSize: 13), .foregroundColor: NSColor(calibratedWhite: 0.38, alpha: 1)]
)

for (offset, item) in versions.enumerated() {
    let column = offset % 2
    let row = offset / 2
    let x = CGFloat(24 + column * 624)
    let y = CGFloat(row == 0 ? 468 : 42)
    let card = NSRect(x: x, y: y, width: 600, height: 396)
    NSColor(calibratedWhite: 1, alpha: 1).setFill()
    NSBezierPath(roundedRect: card, xRadius: 15, yRadius: 15).fill()
    ("VERSION \(String(format: "%02d", item.0))  ·  \(item.1)" as NSString).draw(
        at: NSPoint(x: x + 16, y: y + 372),
        withAttributes: [.font: NSFont.systemFont(ofSize: 14, weight: .semibold), .foregroundColor: NSColor(calibratedWhite: 0.13, alpha: 1)]
    )
    let imagePath = "/Users/wuwanqi/Documents/ChatGPT/5013/Labs/discount-illusion/screenshots/versions/version-\(item.0).jpg"
    let image = NSImage(contentsOfFile: imagePath)!
    image.draw(in: NSRect(x: x + 12, y: y + 10, width: 576, height: 360))
}

("Original saved opening-screen captures · 1200 × 750 each" as NSString).draw(
    at: NSPoint(x: 30, y: 18),
    withAttributes: [.font: NSFont.systemFont(ofSize: 11), .foregroundColor: NSColor(calibratedWhite: 0.4, alpha: 1)]
)
NSGraphicsContext.restoreGraphicsState()
let png = bitmap.representation(using: .png, properties: [:])!
try png.write(to: URL(fileURLWithPath: output))
